# Formato e roteiro geral da estação OSCE do P7

## Metadados

- Disciplina: OSCE
- Especialidade: Metodologia / formato de prova
- Unidade: A_DEFINIR
- Prioridade: alta
- Risco clínico: baixo
- Status: reviewed_l1
- Camada de fonte usada: B
- fonte_visual: sim (`assuntos OSCE p7 2025.1`, p. 1 — imagem fotografada, lida por visão; documento avulso da pasta de ingest, fora do array de fontes mapeadas do cluster, usado aqui só para confirmar a lista oficial de estações 2025.1)
- Fontes usadas: `OSCE .pdf` (camada B, ~p. 1 — orientações gerais); `FACILITA OSCE (1).pdf` (camada B, ~p. 1-2 — roteiro de exame físico no manequim)
- Evidência de prova/devolutiva: fotografia lista conteúdos/temas de 2025.1. Ela
  comprova que temas foram anunciados, **não** comprova checklist aplicado,
  pontuação, pesos, itens eliminatórios ou gabarito oficial.
- Limitações da fonte: ambas as fontes textuais são material de revisão feito por colegas (camada B) para o próprio OSCE, não o roteiro oficial da coordenação de curso. Não há, em nenhuma fonte disponível, tempo cronometrado por estação, número total de estações do dia nem a grade de pontuação do checklist — esses três dados ficam como pendência (`confirmar no slide`/com a coordenação).
- Verificação nível 1: CONFIRMADO

## Como cai

O OSCE do P7 é organizado por **cabines temáticas** (uma por assunto/especialidade — ex.: "cabine de neurologia", "cabine de urologia"), cada uma com um caso clínico curto seguido de **comandos numerados**. O candidato entra, cumprimenta e examina um paciente-ator ou manequim, lê exames complementares já prontos dentro da cabine, e precisa responder aos comandos **na ordem em que aparecem**, sem pular nenhum. O padrão observado nas 152 questões teóricas do P7 (aplicar critério, priorizar antes de tratar, checar contraindicação antes de fechar conduta) se repete aqui, mas a variável decisiva muda: não é "qual é a resposta certa", é **"qual comando estou respondendo agora"**.

## A estação

- **Tarefa:** ler o caso clínico da cabine, examinar o paciente/manequim, interpretar exame(s) complementar(es) já disponível(is) na cabine e responder cada comando numerado, na ordem, sem deixar nenhum sem resposta.
- **Tempo:** não informado nas fontes disponíveis (nem OSCE .pdf nem FACILITA trazem cronometragem) — **pendência: confirmar com a coordenação/colegas de turma anterior antes da prova**.
- **Ator/paciente:** varia por cabine — pode ser um manequim ("boneco") com achados colados no corpo (sobretudo nas estações de pele/geral) ou o exame físico já vir descrito no caso quando a cabine é pobre em achado físico simulável (ex.: neurologia).
- **Material:** prontuário/caso clínico impresso na cabine, resultado(s) de exame(s) complementar(es) (imagem, laboratório) já disponível(is) — "eles não estão ali à toa", ou seja, todo exame fornecido na cabine é para ser lido e usado, não é enfeite.
- **Rubrica sintética de treino (não oficial):** apresentação nominal,
  higienização das mãos, leitura dos comandos, exame adequado, respostas e
  fechamento. Use para praticar consistência; não alegue que cada item pontua ou
  zera sem o instrumento aplicado.

## Pivô clínico

O pivô de treino é o **comando**. Cada comando pede uma coisa específica. Não há pesos oficiais disponíveis; responder na ordem é estratégia pedagógica, não regra confirmada da banca.

## Palavras-âncora

Comando · prontuário · exame físico · manequim · resultado disponível · higienizar as mãos · apresentar-se · hipótese diagnóstica · conduta · orientar o paciente · despedir-se.

## Operação × movimento

| Operação exigida | Variável decisiva | Tipo | Natureza | Movimento provável no erro | Treino que corrige |
|---|---|---|---|---|---|
| executar a tarefa pedida | correspondência comando → resposta (1 comando = 1 resposta, na ordem) | sequência | operacional | sobre-elaboração — responder um comando futuro (ex.: já dar a conduta definitiva) dentro da resposta de um comando anterior que só pedia a hipótese | treinar "comando por comando": ler todos os comandos primeiro, sublinhar o verbo de cada um, e só então responder um de cada vez, em voz alta, sem adiantar o próximo |
| executar roteiro sintético de higiene/apresentação | praticar higienização, apresentação e fechamento | sequência | operacional | confundir treino consistente com checklist oficial | usar os 7 passos como mnemônico de treino; pesos, obrigatoriedade e avaliação real são desconhecidos |
| interpretar imagem/ecg/laboratório | todo exame complementar entregue na cabine tem função na resposta | fato | operacional | não usar um achado fornecido porque "não foi perguntado explicitamente" — o comando geralmente pede a hipótese/conduta e espera que o exame já disponível tenha sido lido e citado como parte da justificativa | treinar o hábito de nomear em voz alta cada exame complementar da cabine antes de fechar qualquer resposta, mesmo que o comando não use a palavra "exame" |

## Dados de precisão

| Dado | Valor | Fonte (página) | Status |
|---|---|---|---|
| Roteiro curricular de treino descrito no material B | cumprimentar/apresentar-se → lavar as mãos → ler prontuário e iniciar atendimento → exame físico + leitura de exames disponíveis → verificar se todos os comandos foram respondidos → lavar as mãos → despedir-se e agradecer | OSCE .pdf, p. 1 (camada B) | CURRICULAR_CONFIRMED — não é checklist/pontuação oficial |
| Roteiro de exame físico no manequim (achados "colados") | avisar que vai examinar → higienizar as mãos → pedir licença e retirar o pano → varrer cabeça → tronco → MMSS → MMII (inclusive calcanhares) → virar o manequim e checar dorso/região sacral → vestir e cobrir o paciente ao final | FACILITA OSCE (1).pdf, ~p. 1 (camada B) | CONFIRMADO |
| Temas anunciados para o OSCE P7 A e B — 2025.1 (5 blocos; não prova checklist aplicado) | Neurologia: AVCi, AVCh, Coma, Cefaleia, TCE · Urologia: Litíase, HPB, Câncer de próstata, Trauma urinário 1 e 2, Câncer renal · Nefrologia: Doença Renal do Diabetes, DRC, Glomerulopatia primária, Glomerulopatia secundária, IRA · Endocrinologia: Diagnóstico/tratamento do Diabetes, Hipertireoidismo, Nódulos de tireoide, Hiperandrogenismo · Pediatria: Febre Reumática, Assistência ao RN, Diarreia, Aleitamento, Atopias | `assuntos OSCE p7 2025.1` (imagem fotografada, p. 1) | CURRICULAR_CONFIRMED — lista de temas, não rubrica oficial |
| Tempo por estação / nº total de estações do dia | não informado em nenhuma fonte disponível | — | confirmar no slide/com a coordenação |

## Pegadinhas

**Erros de treino de alto impacto na rubrica sintética (não zeram oficialmente nem representam regra de banca):**

- Não se apresentar ao paciente/ator no início.
- Não verbalizar higiene das mãos quando pertinente; o peso real é desconhecido.
- Examinar o manequim sem avisar o paciente e sem pedir licença antes de descobrir o corpo.
- Sair da cabine com um comando sem resposta (a orientação geral manda explicitamente "verificar se todos os comandos foram respondidos" antes de lavar as mãos e se despedir).
- Ignorar um exame complementar já disponível na cabine e fechar a resposta só pela história clínica — o material "não está ali à toa".
- Não se despedir/agradecer ao final.

## Distratores sedutores

| Distrator | Por que seduz | Movimento que sugere | Por que erra |
|---|---|---|---|
| Responder a conduta definitiva quando só foi pedida hipótese | ansiedade de demonstrar domínio | sobre-elaboração | prejudica clareza e aderência ao comando; a pontuação real é desconhecida |
| Pular a higienização das mãos porque "a cabine não tem pia visível" | parece só formalidade cênica | fechamento precoce | o material B recomenda treinar higienização; se o gesto é pontuado e com qual peso permanece desconhecido |
| Ignorar o resultado de exame já impresso na cabine e responder só com o quadro clínico da história | o aluno já "fechou" o diagnóstico mentalmente antes de olhar o exame | fechamento precoce / narrativa acima do discriminador | o material da cabine ("resultado disponível") é colocado ali propositalmente para ser a peça que confirma ou muda a hipótese — não citá-lo é deixar de usar o discriminador que a banca disponibilizou |

## Conduta

- Inicial de treino: cumprimentar + apresentar-se + lavar as mãos + ler o prontuário/caso clínico.
- Sequência de treino: examinar (manequim ou paciente-ator, pedindo licença) + interpretar todo exame complementar já disponível + responder cada comando numerado, na ordem, sem pular nenhum.
- Escopo: é um roteiro sintético de consistência, não checklist, peso ou regra eliminatória oficial.
- Segurança clínica: em cenário de saúde mental, avaliar risco quando os dados/comando o exigirem; não inventar comando implícito universal da banca.
- O que mudaria a decisão: se o comando pede explicitamente "oriente o paciente" ou "cite diferenciais", o alvo da resposta muda de "conduta médica" para "explicação em linguagem leiga" ou "lista comparativa" — ler o verbo do comando decide o formato da resposta, não só o conteúdo.

## Mini-casos ativos

1. Você está na cabine de Nefrologia. O comando 3 diz "Quais exames devem ser solicitados?" e o comando 4 diz "Descreva a sua conduta." Você já sabe que é GNDA e que o tratamento é sintomático. **Pivô:** o comando 3 pede só exames — responda exames, guarde a conduta para o comando 4, mesmo sabendo a resposta final de cabeça.
2. Você entra na cabine de Urologia, vê o exame de USGTR e o PSA já impressos na bancada, mas o comando 1 só pergunta "qual a hipótese diagnóstica?". **Pivô:** cite o achado do exame (PSA e relação livre/total) como parte da justificativa da hipótese, mesmo que o comando não use a palavra "exame" — o material foi entregue para ser usado, não para ser decorativo.
3. Você examina o manequim de uma estação com queixa abdominal e encontra uma lesão de pele nas costas que não tem relação óbvia com a queixa principal. **Pivô:** mencione o achado mesmo assim — a orientação geral do exame físico no manequim manda varrer o corpo todo e "mencionar qualquer úlcera/achado", especialmente em idosos, independente de parecer relevante à queixa central.

## Cards mínimos

| Frente | Verso | Tipo |
|---|---|---|
| Quais são os 7 passos do roteiro sintético de treino? | Cumprimentar/apresentar-se → lavar as mãos → ler prontuário → exame físico + exames disponíveis → conferir se todos os comandos foram respondidos → lavar as mãos → despedir-se/agradecer; não é checklist oficial | fato |
| No manequim, antes de examinar, o que devo fazer? | Avisar o paciente, higienizar as mãos, pedir licença para retirar o pano que cobre o boneco | sequência |
| Um comando pede só a hipótese diagnóstica — devo já explicar a conduta? | Não — responda apenas o que o comando pediu; guarde a conduta para o comando que a solicitar | regra |
| Encontrei um achado no manequim que não parece ligado à queixa principal. Cito? | Sim — sempre mencione qualquer achado localizado durante a varredura completa do corpo | regra |

## Revisão

- Revisar quando: antes de qualquer simulação de estação nova, e sempre que praticar uma especialidade diferente pela primeira vez.
- Critério de parada de treino: executar os 7 passos do roteiro sintético e responder comando por comando, sem pular nenhum e sem antecipar respostas futuras, em 3 estações seguidas de especialidades diferentes; não inferir pontuação oficial.
