# Transtornos Mentais na Gravidez e no Puerpério

## Metadados

- Disciplina: EISM
- Especialidade: Psiquiatria
- Unidade: I
- Prioridade: alta
- Risco clínico: alto
- Status: reviewed_l1
- Transcription: confirmed
- Curricular alignment: confirmed
- Clinical validity: pending (claims de psicofármacos/lactação quarantined até revisão individual)
- Independent review: reviewed_l1
- Reviewer ID: `agent:clinica_reparos:2026-08-20`
- Camada de fonte usada: A+B (slide do Prof. José Kenio confirma, quase linha a linha, a apostila nativa)
- fonte_visual: sim (`2_Transtornos_Mentais_na_Gravidez_e_No_Puerpe_rio__0efe14a107` pp. 1–2, 8, 12, 14–16, 18)
- Fontes usadas: Transtornos_mentais_e_comportamentais_relacionados_ao_puerpe__d60fdbc256; 2_Transtornos_Mentais_na_Gravidez_e_No_Puerpe_rio__0efe14a107 (slides do Prof. José Kenio)
- Evidência de prova/devolutiva: sem evidência de cobrança específica no Source Pack; o cluster aponta blues × DPP × psicose puerperal como discriminador de alto valor
- Limitações da fonte: nenhuma — dado numérico principal foi lido tanto na apostila quanto no slide fotografado, com convergência total
- Verificação nível 1: CONFIRMADO

## Como cai

Sem evidência de prova antiga específica no Source Pack. Pelo padrão do blueprint EISM, espere:
vinheta com puérpera em determinado dia/semana pós-parto pedindo classificar blues × DPP ×
psicose puerperal e definir conduta; pegadinha de rotular todo humor alterado pós-parto como
"depressão pós-parto"; pergunta sobre segurança de psicofármaco específico na amamentação.

## Conceito operacional mínimo

Os transtornos afetivos puerperais formam um continuum de gravidade: blues (mais leve, comum,
autolimitado) → depressão pós-parto (quadro depressivo maior instalado no puerpério) → psicose
puerperal (mais grave, emergência psiquiátrica). Puerpério = 6–8 semanas após o parto (expulsão
da placenta). Até 85% das puérperas têm alguma alteração de humor; 10–15% têm sintomas
significativos.

## Pivô clínico

Diante de qualquer depressão pós-parto, investigar ativamente sintomas prévios de mania/hipomania
— a chance do primeiro episódio de humor de um Transtorno Bipolar ocorrer no puerpério é 7x maior
que em outras fases da vida (numa amostra citada na fonte, 56% dos quadros inicialmente
rotulados como "depressão pós-parto" eram, na verdade, TAB). Psicose puerperal é sempre
emergência: instala-se rápido (pródromo de inquietação/irritabilidade/insônia evoluindo em dias
para quadro psicótico), tem alta associação com bipolaridade e risco de infanticídio.

## Palavras-âncora

blues puerperal (disforia puerperal) · depressão pós-parto · psicose puerperal · continuum de
gravidade · virada maníaca · pistas de bipolaridade · emergência psiquiátrica · psicofármacos e
lactação

## Operação × movimento

| Operação exigida | Variável decisiva | Tipo | Natureza | Movimento provável no erro | Treino que corrige |
|---|---|---|---|---|---|
| diferenciar próximos | tempo pós-parto + prejuízo funcional (blues até 2 sem / DPP crítico até 12 sem / psicose até 3 sem) | limiar | operacional | pivô perdido | 3 vinhetas variando só o dia pós-parto, forçando classificar antes de escolher conduta |
| priorizar emergência | velocidade de instalação + sintomas psicóticos (pródromo em dias, pico 48-72h) | sinal-achado | operacional | definitiva antes da inicial | checklist: há sintoma psicótico/pródromo rápido? se sim, tratar como emergência antes de qualquer outra decisão |
| reconhecer risco | lactante em psicofármaco exige avaliação fármaco/dose/RN e decisão compartilhada | contraindicação | misto | aplicar regra absoluta | consulta a fonte específica por fármaco |
| diferenciar próximos | pistas de bipolaridade (pensamento acelerado, sintomas psicóticos, início puerperal) antes de fechar DPP unipolar | sinal-achado | operacional | narrativa acima do discriminador | antes de tratar como DPP, nomear se há pista de mania/hipomania no enunciado |

## Dados de precisão

| Dado | Valor | Fonte (página) | Status |
|---|---|---|---|
| Puerpério — duração | 6–8 semanas após o parto | Karen p.1; slide p.2 | CONFIRMADO (A+B) |
| Alteração de humor no puerpério | até 85% das puérperas (maioria leve; 10–15% significativa) | Karen p.1 | CONFIRMADO |
| Blues — incidência / início / duração | 50–85% das puérperas / primeiros dias pós-parto / até 2 semanas | Karen p.2; slide p.8 | CONFIRMADO (A+B, números idênticos) |
| DPP — incidência / início / período crítico | 10–15% / geralmente nas 6 primeiras sem. / crítico nas 12 primeiras sem. | Karen p.2 | CONFIRMADO |
| DPP — recorrência em gestações seguintes | até 80% | Karen p.2 | CONFIRMADO |
| DPP — risco se episódio depressivo já na gestação | até 60% dos casos de DPP já tinham depressão na gestação | Karen p.2 | CONFIRMADO |
| Puérperas com dx inicial de depressão que eram TAB | 56% (amostra de 56 puérperas); só 44% confirmaram depressão | Karen p.3; slide p.12 | CONFIRMADO (A+B, números idênticos) |
| Chance do 1º episódio de humor do TAB ocorrer no puerpério | 7x maior que em outras fases da vida | Karen p.3; slide p.12 | CONFIRMADO (A+B) |
| Psicose puerperal — incidência | 2 em cada 1.000 partos | Karen p.5; slide p.14 | CONFIRMADO (A+B) |
| Psicose puerperal — janela de instalação | primeiras 3 semanas pós-parto, em geral entre 48–72h | Karen p.5; slide p.14 | CONFIRMADO (A+B) |
| Psicose puerperal — taxa de infanticídio se não tratada | ~4% | Karen p.5; slide p.15 | CONFIRMADO (A+B) |
| Psicose puerperal maniforme → evolução para TAB | 50% | Karen p.5; slide p.15 | CONFIRMADO (A+B) |
| Olanzapina/quetiapina/risperidona — doses na lactação | valores constam no resumo, sem overlay farmacológico atual | Karen p.6 | QUARANTINED — não usar em prescrição |
| Lítio e aleitamento | regra absoluta de suspender aleitamento consta no material | slide/resumo | QUARANTINED — decisão individual especializada |

## Pegadinhas

- Sintomas de humor no 4º–5º dia pós-parto NÃO são automaticamente blues — só se forem leves,
  autolimitados e sem prejuízo funcional; persistência >2 semanas reclassifica para investigação
  de depressão maior.
- As regras de “seguro/inseguro” do slide para antidepressivos e lítio são
  `HISTORICAL_ONLY/QUARANTINED`. Compatibilidade depende de fármaco, dose, idade/
  prematuridade do bebê, monitorização e risco de suspender tratamento ou leite.

## Distratores sedutores

| Distrator | Por que seduz | Movimento que sugere | Por que erra |
|---|---|---|---|
| Rotular toda alteração de humor puerperal como depressão pós-parto e iniciar ISRS de imediato | É a resposta "farmacológica" que parece proativa | pivô perdido | Dentro da janela de 2 semanas e sem prejuízo funcional é blues — conduta é suporte, não fármaco |
| Iniciar antidepressivo isolado numa puérpera com depressão + pensamento acelerado e sintomas psicóticos | Trata a depressão que está evidente | narrativa acima do discriminador | São "pistas" clássicas de TAB — antidepressivo isolado arrisca virada maníaca; investigar mania/hipomania primeiro |

## Conduta

- Inicial: classificar o quadro pelo tempo decorrido, gravidade e prejuízo funcional (blues × DPP
  × psicose puerperal); psicose puerperal = emergência, quase sempre com internação.
- Definitiva: blues — suporte social/familiar, sem fármaco. DPP leve-moderada — psicoterapia
  conforme avaliação. A escolha de psicofármaco na gestação/lactação permanece `QUARANTINED`:
  não existe “1ª escolha global” segura sem avaliação individual, fase gestacional, lactação,
  riscos materno-fetais e diretriz vigente. Psicose puerperal — tratamento imediato especializado,
  lenta e cuidadosa só após remissão completa, acompanhamento por até 1 ano.
- Condição da conduta: mulher em tratamento psiquiátrico que deseja engravidar deve comunicar ao
  psiquiatra para ajuste em tempo hábil — a medicação não deve ser interrompida abruptamente,
  mesmo em esquemas de risco na gestação (nesses casos, o médico orienta/contraindica a gestação,
  mas mantém a medicação se já engravidou).
- Diferencial perigoso: depressão pós-parto tratada como unipolar quando na verdade é a 1ª
  manifestação de TAB → virada maníaca com antidepressivo isolado.
- O que mudaria a decisão: história prévia/familiar de TAB, sintomas psicóticos,
  fármaco/dose, função renal do bebê, prematuridade e possibilidade de monitorização.
  Lítio não autoriza uma regra automática de suspender leite ou medicação.

## Mini-casos ativos

1. Puérpera, 5 dias pós-parto, choro fácil, ansiedade leve, cuida bem do bebê, sem prejuízo
   funcional → blues puerperal; conduta: suporte, sem fármaco, reavaliar se persistir >2 semanas.
   Variável decisiva: tempo curto + ausência de prejuízo.
2. Puérpera, 10 dias pós-parto, pródromo de insônia e irritabilidade evoluindo em poucos dias
   para delírios e alucinações → psicose puerperal; conduta: emergência, internação, tratamento
   imediato. Variável decisiva: velocidade de instalação + sintomas psicóticos.

## Cards mínimos

| Frente | Verso | Tipo |
|---|---|---|
| Blues × DPP × psicose puerperal — tempo | Blues: dias, até 2 sem. DPP: 6 sem. (crítico até 12 sem.). Psicose: até 3 sem. (pico 48-72h) | discriminador |
| Por que investigar mania/hipomania em toda DPP | Risco 7x maior de 1º episódio de TAB ocorrer no puerpério | risco |
| Taxa de infanticídio na psicose puerperal não tratada | ~4% | dado numérico |
| Psicofármaco na lactação | consultar fonte específica; não usar lista de classe | guardrail |
| Lítio e aleitamento | decisão individual especializada; regra antiga quarantined | risco |

## Revisão

- Revisar quando: antes de qualquer simulado que misture humor/depressão com puerpério — os dois
  temas se cobram juntos.
- Critério de parada: preencher de cabeça a tabela tempo×gravidade dos três
  quadros puerperais e explicar por que a escolha farmacológica é individualizada;
  não promover sertralina ou esquemas antigos a regra global.

## Para a prova/material histórico

O material ensina sertralina como escolha ampla e “suspender amamentação, manter
lítio”. Isso está curricularmente conferido, mas não foi validado como conduta
atual e fica excluído do aconselhamento real. Consultar a cápsula
`aleitamento_materno.md` e fonte farmacológica específica.
