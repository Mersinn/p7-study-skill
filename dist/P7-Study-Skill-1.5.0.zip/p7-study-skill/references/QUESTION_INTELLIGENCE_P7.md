# QUESTION_INTELLIGENCE — P7

## 1. Propósito

Toda questão médica é um caso clínico comprimido.

O objetivo não é apenas acertar a alternativa. É caracterizar com precisão o que
o item exige e, **quando houver evidência individual**, formular uma hipótese
falsificável sobre o movimento do aluno.

## 2. Dois domínios, nunca fundidos

A unidade do diagnóstico é o desalinhamento:

> **desalinhamento( operação exigida [questão] , movimento candidato [tentativa] )**

- **Question Intelligence / PLANO A — a questão (objetivo e compartilhável).**
  Operação exigida (enum §4) + natureza da demanda (`factual | operacional |
  mista`) + variável decisiva tipada (`fato | valor | limiar | função | sequência |
  prioridade | contraindicação | sinal-achado`) + validade do item
  (`full | partial | ambíguo | insuficiente`).
- **Learner State — a tentativa e a trajetória (pessoal, privado e inferido).**
  Resposta + confiança pré-feedback + `movimento_candidato` + evidência a favor e
  contra + alternativas + confiança diagnóstica + estado da hipótese.

Não existe “Plano B” dentro da questão. O Plano A permanece igual para alunos
diferentes; o Learner State só existe para uma tentativa observada e segue
`LEARNER_STATE_PROTOCOL.md`.

Item ambíguo ou insuficiente → **não** infira movimento do aluno. Corrija o item ou
declare a informação ausente antes de analisar a tentativa.

### 2.1 Três planos de proveniência e escopo

Question Intelligence descreve o item usando três planos relacionados, mas
ortogonais:

- `Aula/Curricular Intelligence`: `source_id`, localizador, sinal observado da
  aula (`slide | grifo | repetição | exemplo | questão/devolutiva`) e operação de
  prova. Isso descreve o ensino, não o aluno e não a vigência clínica.
- `Clinical Validity`: `claim_id` e estado `current | pending |
  historical_only | conflict | quarantined`. Isso governa se a chave pode ser
  apresentada como prática atual.
- `Learner State / Pattern Analyzer`: eventos realmente observados da tentativa.
  Estrutura do item entra como contexto; só resposta, justificativa, confiança
  pré-feedback, trajetória e transferência entram como evidência pessoal.

Use `answer_key_scope: curricular` quando a chave pede literalmente o que foi
ensinado, mesmo que o claim esteja não vigente ou não resolvido. Esse resultado
pode sustentar `inference_scope: curricular_performance` ou, com rastros
adequados, `reasoning_operation`; nunca `clinical_current_practice`. Se o item
pergunta prática atual e o claim não é `current`, marque a validade como
`partial | ambíguo | insuficiente` e não infira movimento do aluno.

Quarentena clínica não apaga a aula. Ela bloqueia apenas a promoção silenciosa a
conduta vigente. Uma divergência aula × diretriz pode virar excelente item de
comparação, desde que os dois painéis e o escopo do gabarito estejam explícitos.

**Gate anti-contaminação.** Defina `answer_key_scope` antes de corrigir e aplique
a chave somente dentro dele. Uma alternativa correta na prática atual, mas
divergente de uma chave curricular histórica, é `scope_disagreement` — não
distrator cognitivo, erro clínico nem evidência de movimento. Nesse caso,
`inference_scope: none`, salvo se o enunciado declarou o escopo antes da tentativa
e houver rastro positivo na justificativa, execução ou trajetória — não apenas o
resultado da chave. Mesmo então, a inferência fica limitada a
`curricular_performance` ou `reasoning_operation`; nunca é promovida a domínio de
prática atual. Claim `pending | historical_only | conflict | quarantined` não
sustenta `clinical_current_practice`.

## 3. Campos internos

```yaml
question_intelligence:
  source_id: ""
  claim_id: ""
  curricular_frame: ""   # faculty_current_cycle | faculty_historical | synthetic_training | external_current
  clinical_validity: ""  # current | pending | historical_only | conflict | quarantined | not_applicable
  answer_key_scope: ""   # curricular | clinical_current_practice | reasoning_only
  scope_alignment: ""    # aligned | scope_disagreement | unresolved
  comando_explicito: ""
  comando_implicito: ""
  disciplina: ""          # EISA_II | EISCA | EISM | CASOS | OSCE
  tema: ""
  subtema: ""
  pivo_clinico: ""
  palavra_ancora: ""
  operacao_id: ""         # enum estável da §4
  operacao_exigida: ""    # rótulo humano derivado; nunca substituir o ID
  natureza_da_demanda: "" # factual | operacional | mista
  variavel_decisiva: ""   # o discriminador, sem a resposta resolvida antes da tentativa
  tipo_discriminador: ""  # fato | valor | limiar | função | sequência | prioridade | contraindicação | sinal_achado
  variavel_localizador: "" # onde está no enunciado/imagem/lab/fonte
  regra_aplicacao: ""      # como separa a correta das finalistas
  validade_do_item: ""
  distractor_map: {}      # alternativa → {movement_ids: [], rationale: "", specificity: specific|nonspecific}
  pegadinha: ""
  regra_de_prova: ""
  conduta_inicial_vs_definitiva: ""
  diferencial_perigoso: ""
  gatilho_seguranca_medica: ""
  dado_que_mudaria_a_conduta: ""
  logica_da_correta: ""
  logica_das_erradas: ""
learner_observation:
  inference_scope: ""    # curricular_performance | clinical_current_practice | reasoning_operation | none
  learner_answer: ""
  learner_confidence_before_feedback: null
  movimento_candidato: ""
  evidencia_a_favor: []
  evidencia_contra: []
  explicacoes_alternativas: []
  diagnostic_confidence: ""
  hypothesis_status: "" # candidate | confirmed | weakened | abandoned | indeterminate
  validade_metacognitiva: ""
```

Não imprima o YAML salvo se ajudar. É estrutura interna.

### 3.1 Natureza da demanda do item

- `factual`: a resolução depende principalmente de recuperar definição, valor,
  dose, critério ou contraindicação;
- `operacional`: o dado está disponível e a resolução depende principalmente de
  aplicar, ordenar, priorizar ou discriminar;
- `mista`: recuperação factual e execução operacional são materialmente
  inseparáveis.

Essa classificação pertence ao item. Ela **não** prova a causa do erro. Questão
operacional errada pode refletir lacuna factual; questão factual errada pode
refletir leitura. A causa individual exige evidência do aluno.

## 4. Operações exigidas (enum estável, 12)

Persista e compare pelo ID; mostre ao aluno `rótulo humano` ou `ID — rótulo`.
Rótulos podem ser ajustados sem migrar eventos. IDs não podem ser renomeados.

| `operacao_id` | `operacao_exigida` (rótulo humano) |
|---|---|
| `OP_RECOGNIZE_DIAGNOSIS` | reconhecer diagnóstico |
| `OP_INITIAL_MANAGEMENT` | escolher conduta inicial |
| `OP_DEFINITIVE_MANAGEMENT` | escolher conduta definitiva |
| `OP_INITIAL_EXAM` | escolher exame inicial |
| `OP_BEST_EXAM` | escolher melhor exame |
| `OP_DIFFERENTIATE` | diferenciar diagnósticos próximos |
| `OP_IDENTIFY_COMPLICATION` | identificar complicação |
| `OP_APPLY_CRITERION` | aplicar critério |
| `OP_PRIORITIZE_EMERGENCY` | priorizar emergência |
| `OP_INTERPRET_IMAGE_ECG_LABS` | interpretar imagem/ECG/laboratório |
| `OP_RECOGNIZE_CONTRAINDICATION` | reconhecer contraindicação |
| `OP_COMPARE_FUNCTION` | comparar função/finalidade |

Escolha **uma** operação primária: a ação mínima que produz a resposta pedida.
Operações auxiliares podem ser descritas na explicação, mas não entram no par
`operação exigida × movimento observado`.

### 4.1 Variável decisiva operacional

Registre uma variável que passe por este teste contrafactual: entre as alternativas
finalistas, mudar apenas essa variável mudaria a chave. Se não mudaria, ela é
contexto, não variável decisiva. Preencha `variavel_decisiva`,
`tipo_discriminador`, `variavel_localizador` e `regra_aplicacao`; se dois dados
forem inseparáveis, registre uma tupla explícita, não duas listas vagas. Item sem
discriminador recuperável é `ambíguo | insuficiente` e não sustenta Learner State.

## 5. Movimentos (IDs para inferência; cada um com intervenção própria)

| Macro | `movement_id` — rótulo humano |
|---|---|
| Conteúdo | `M_CONTENT_GAP` — lacuna; `M_WRONG_VALUE` — valor errado; `M_MISLEARNED_RULE` — regra mal-aprendida |
| Interpretação | `M_COMMAND_SWAP` — troca de comando; `M_READING_MISS` — erro de leitura; `M_PIVOT_MISSED` — pivô perdido |
| Validação externa | `M_VALIDATION_ANALOGY_MISMATCH` — analogia sem validação funcional; `M_NARRATIVE_OVER_DISCRIMINATOR` — narrativa acima do discriminador; `M_UNCHECKED_PREMISE` — premissa não checada; `M_OVEREXTRAPOLATION` — superextrapolação |
| Decisão | `M_PREMATURE_CLOSURE` — fechamento precoce; `M_REOPENED_CORRECT` — reabriu resposta certa; `M_OVERELABORATION` — sobre-elaboração |
| Priorização | `M_DEFINITIVE_BEFORE_INITIAL` — definitiva antes da inicial; `M_PROBABLE_BEFORE_DANGEROUS` — provável antes da perigosa |
| Abstenção | `M_INDETERMINATE` — indeterminado |

Movimento é hipótese personalizada da tentativa, nunca classe universal. Toda
tentativa N=1 produz no máximo `candidate`; sem sinal observado,
`M_INDETERMINATE`. Os rótulos não autorizam inferência por si mesmos.

Intervenções distintas preservadas: `M_VALIDATION_ANALOGY_MISMATCH` → perguntar
quais propriedades da fonte seguem válidas no alvo; `M_NARRATIVE_OVER_DISCRIMINATOR`
→ pedir a única variável que separa as finalistas antes de marcar.

## 6. Mapa distrator → movimento

Mapeie **cada alternativa errada** para zero, um ou vários `movement_ids`
(relação distrator 1:N). O mapa pertence ao item e deve ser criado antes de usar
a resposta do aluno:

```yaml
distractor_map:
  B:
    movement_ids: [M_COMMAND_SWAP, M_PIVOT_MISSED]
    rationale: "responde ao melhor exame, embora o comando peça o inicial"
    specificity: specific
```

`rationale` deve ligar conteúdo da alternativa + comando + variável decisiva ao
movimento; repetir a definição do movimento não basta. Use `specific` somente
quando esse caminho explica a alternativa melhor que os concorrentes. Use
`nonspecific` ou `movement_ids: []` quando múltiplas causas gerais cabem — não
adicione `M_CONTENT_GAP` por padrão. A alternativa correta não recebe movimento.

Marcar um distrator `specific` pode gerar todos os movimentos listados como
**candidatos concorrentes**, teto de confiança baixa; nunca selecione um vencedor
sem evidência adicional. Distrator curricular que é resposta válida em outro
`answer_key_scope` cai no gate anti-contaminação da §2.1 e não entra neste mapa
para inferência pessoal.

## 7. Confiança ordinal e abstenção

Faixas: `insuficiente · baixa · moderada · alta`. Nunca porcentagem.

- distrator sozinho → **teto baixa** ("compatível"), nunca "confirmado";
- ao menos três distratores específicos e consistentes em itens independentes no
  bloco → candidato **moderado**, com numerador/denominador, mesmo sem texto;
- justificativa explícita e alinhada em uma tentativa → até **moderada**;
- confiança **alta** exige trajetória independente/transferência válida; o estado
  `confirmed` continua uma decisão separada, regida pelo ciclo de evidência;
- movimento repetido entre sessões (caderno de erros) → **eleva uma faixa**;
- **marcadores conflitantes** (ex.: declara certeza + diz que chutou) → **abster**;
- auto-relato pós-gabarito → teto menor que evidência objetiva;
- sem alternativa mapeada, sem padrão de bloco e sem trajetória →
  **INDETERMINADO**.

Uma ocorrência (`N=1`) nunca recebe `confirmed`. Confirmação exige pelo menos duas
evidências independentes em itens/contextos distintos, sendo ao menos uma
transferência válida da mesma operação em outro conteúdo. Teste contaminado por
falta de conteúdo, chute, pista decisiva ou item inválido não confirma nem refuta.

`INDETERMINADO` **não** é lacuna de conteúdo. Só vira lacuna de conteúdo com
evidência independente que a sustente.

## 8. Regra do silêncio — correção herdada do piloto Diagnos 1C-A

> **Ausência de menção não é evidência de ausência de operação.**

Esta regra existe por um resultado experimental, não por teoria.

No piloto controlado da Fase 1C-A (2026-07-28, 40 agentes cegos, 8 cenários), o
cenário S7 plantou um aluno que **leu o comando corretamente** e apenas não sabia
qual exame era o inicial — e disse que não lembrava. O motor de diagnóstico
concluiu, como hipótese líder, *"acerto por reconhecimento prototípico, **sem
processar o comando temporal** do enunciado"*. Ele afirmou o oposto do que ocorreu.
O adjudicador nomeou a falha: **conversão de silêncio em fato** — nenhum sinal
dizia que o aluno não leu o comando; o diagnóstico derivou "não executou" da
ausência de menção. Foi a única refutação limpa de hipótese do piloto.

A regra proíbe **uma** coisa, com precisão cirúrgica:

> Não afirme que o aluno **deixou de executar** uma operação apenas porque ele não
> a mencionou.

Ela **não** proíbe diagnosticar quem responde só com a letra. Isso seria jogar
fora o motor inteiro.

### 8.1 O que continua sendo sinal legítimo sem nenhuma justificativa escrita

Resposta só com alternativas é **sinal denso**, não ausência de sinal. Continuam
valendo, e devem ser usados:

- **a alternativa marcada** — via mapa distrator → movimento (§6). Marcar uma
  alternativa mapeada já gera movimento candidato em confiança **baixa**;
- **o padrão dentro do bloco** — 10 questões respondidas revelam concentração de
  erro por operação (todo erro em "conduta inicial", nenhum em "reconhecer dx");
- **a estrutura do item** — qual operação ele exigia e qual variável decidia;
- **a semântica do enunciado** — que leitura do texto levaria àquela alternativa;
- **a forma da alternativa escolhida** — a mais longa, a mais completa, a mais
  segura, a que repete termo do enunciado;
- **o padrão de prova** — se o item tinha comando inverso e ele respondeu como se
  fosse direto, isso é rastro de leitura, não especulação;
- **a trajetória** — o mesmo movimento reaparecendo entre sessões (caderno de
  erros) é evidência longitudinal e **eleva** a confiança;
- **os três tempos** — o que ele sabia antes, o que produziu agora, o que faz na
  revisão em 48h.

Com bloco inteiro respondido e padrão consistente, a hipótese pode chegar a
**moderada** sem justificativa escrita, mas continua `candidate`. Confiança alta ou
`confirmed` exige evidência independente/transferência, não apenas concentração no
mesmo bloco.

### 8.2 O que continua proibido

- afirmar que ele **não leu** o comando porque não o citou;
- afirmar que ele **não considerou** um diferencial porque não o nomeou;
- afirmar que **não sabia** o critério quando ele acertou por outro caminho;
- converter uma única resposta em curta em "não raciocinou";
- transformar explicação alternativa em hipótese líder por falta de concorrente.

A diferença entre §8.1 e §8.2: lá se **infere movimento a partir do que existe**;
aqui se **inventa déficit a partir do que falta**.

### 8.3 Teste antes de fechar o diagnóstico

Pergunte: *qual rastro observado sustenta isso?*

- Se a resposta for "a alternativa que ele marcou está mapeada para esse
  movimento", **é válido** — em confiança baixa, e sobe com padrão de bloco.
- Se a resposta for "ele não falou disso", **derrube a hipótese**.

`INDETERMINADO` é para quando não há alternativa mapeada específica, padrão de
bloco suficiente nem trajetória — inclusive bloco heterogêneo sem operação
comum observável. Não é obrigatório para toda resposta sem texto nem proibido
em bloco: uma concentração objetiva de rastros pode sustentar candidato
moderado mesmo sem justificativa escrita.

## 9. Correção independente

Não confie na alternativa marcada pelo aluno. Corrija por conta própria.

Se o gabarito informado conflitar com o raciocínio:

1. declare o conflito;
2. explique o raciocínio;
3. diga qual informação resolveria;
4. não invente o dado ausente.

## 10. Saída da correção

```text
Comando:
Disciplina · Tema/subtema:
Operação exigida (Plano A): <operacao_id> — <rótulo humano>
Natureza da demanda: factual | operacional | mista
Variável decisiva (Plano A): <valor> · <tipo> · <regra de aplicação>
Validade do item: full | partial | ambíguo | insuficiente
Escopo da chave · validade clínica:
Pivô clínico / palavra-âncora:
Resposta correta + por quê:
Por que as erradas seduzem (distrator → movimentos concorrentes):
Movimento candidato (Learner State; abster se sem evidência → indeterminado):
Evidência a favor / contra:
Confiança diagnóstica: insuficiente | baixa | moderada | alta
Pegadinha / regra de prova:
Card mínimo + revisão:
```

Se o usuário pedir correção rápida, encurte sem perder pivô e pegadinha.

### 10.1 Correção de bloco de múltiplos itens

Quando o aluno enviar respostas de vários itens na mesma mensagem, e os
enunciados/alternativas estiverem disponíveis no pacote permitido da sessão:

1. corrija **cada item**, na ordem, usando uma linha numerada por item e
   mostrando resposta marcada, resposta correta e uma justificativa curta;
   para 10 itens, a saída mínima é uma lista/tabela com 10 linhas — um gabarito
   compacto seguido de escore não substitui a correção item a item;
2. informe o numerador e o denominador do resultado do bloco;
3. só depois faça a leitura de Learner State do bloco, separada da correção
   objetiva;
4. se os erros forem heterogêneos **e não houver operação comum observável**,
   escreva explicitamente **“sem padrão dominante — INDETERMINADO”** e não
   substitua essa conclusão por uma lista de tendências especulativas; temas
   diferentes não anulam, por si só, uma operação transferida;
5. quando pelo menos três rastros, em três ou mais temas, estiverem mapeados
   para o mesmo movimento/operação, nomeie-o como hipótese candidata e informe
   numerador/denominador e pelo menos três exemplos. Mesmo assim, o teto do
   bloco é `candidate`/confiança moderada; `confirmed` exige evidência
   independente e transferência válida conforme `LEARNER_STATE_PROTOCOL.md`.

Se os enunciados/alternativas não estiverem disponíveis, não invente um gabarito
nem finja que corrigiu o bloco: declare evidência insuficiente e peça o conteúdo
completo. Uma string de letras sem o item correspondente não autoriza correção
item a item.

**Invariante de padrão estrutural transferido.** Se, em três ou mais itens de
temas distintos, a alternativa marcada fecha gravidade ou conduta por um único
achado saliente, enquanto a alternativa correta exige verificar o conjunto de
critérios/variáveis objetivos, esses erros constituem o mesmo movimento
observável (narrativa acima do discriminador), mesmo quando o aluno forneceu
somente letras. Conte a fração e cite pelo menos três itens; classifique como
`candidate`/confiança moderada. Isso descreve o padrão de resposta, não prova a
causa cognitiva e não pode virar `confirmed` sem trajetória independente.

No modo calibrado, peça a confiança do aluno **junto da resposta e antes do
feedback** (`B · 75%`). Nunca confunda esse valor com confiança diagnóstica. Só
calcule Brier/viés com `n >= 10` tentativas válidas, conforme
`LEARNER_STATE_PROTOCOL.md`.

## 11. Alto risco

Questão com conduta de alto risco, emergência tempo-dependente, dose,
contraindicação, janela terapêutica ou decisão protocolo-dependente →
aplique `MEDICAL_SAFETY_LAYER.md`.

Em questão objetiva: escolha a alternativa quando houver base · afirme o pivô com
firmeza · separe conduta inicial de definitiva · nomeie a condição que torna a
conduta correta · aponte o dado ausente que mudaria a decisão · explique por que
os distratores **perigosos** erram · declare ambiguidade só quando ela for real.

## 12. Tipos de erro

erro de conteúdo · erro de leitura · erro de comando · erro de sequência de
raciocínio · erro de priorização · erro de conduta · fechamento precoce · falso
domínio · acerto frágil · insegurança mascarada · evidência insuficiente ·
conduta vaga insegura · conduta protocolo-dependente.

## 13. Validade metacognitiva

`validade_plena` · `validade_parcial` · `validade_minima` ·
`validade_cognitiva_zero` · `marcadores_conflitantes` · `evidencia_insuficiente` ·
`sessao_tecnica`.

Regras: chutou e acertou → **acerto frágil** · questão incompleta → **evidência
insuficiente** · sinais conflitantes → **marcadores conflitantes** · sessão
técnica → não inferir padrão cognitivo.

## 14. Frases de honestidade obrigatórias

Questão incompleta:
```text
Evidência insuficiente. Corrijo o conteúdo, mas não infiro padrão cognitivo.
```

Chutou e acertou:
```text
Acerto frágil. Não vou registrar como domínio.
```

Sabia o tema mas perdeu o passo decisivo:
```text
Você reconheceu o tema, mas perdeu o pivô que decidia a conduta.
```

Produção curta demais para inferir:
```text
Sinal insuficiente sobre o seu processo. Corrijo o conteúdo; o movimento fica indeterminado.
```

## 15. Geração de card

Gere card **só** se ele previne erro futuro.

Prefira: card de pivô · de conduta · de pegadinha · de distrator · de diferencial
perigoso · de erro pessoal · de regra de prova · de dose.

Não gere lote grande de cards durante a correção.

## 16. Resposta discursiva

Para discursiva, determine o comando e a rubrica disponível antes de corrigir.
Retorne: pontos obrigatórios · acertos · lacunas · erro médico/ambiguidade ·
organização/prioridade · versão final enxuta. Não invente pesos se não houver
rubrica autêntica. Movimento cognitivo continua opcional e exige sinal presente na
produção; omissão de um ponto é lacuna da resposta, não prova automática de como o
aluno pensou.
